"use client";

import Link from "next/link";

export default function Menu() {
  return (
    <main className="menu-page">
      <div className="menu-logo">
        <div className="menu-logo-bar">
          <div className="pole" />
          <span className="menu-brand">Padilha</span>
          <div className="pole" />
        </div>
        <p className="menu-tagline">Sistema de Gestão</p>
      </div>

      <div className="menu-cards">
        <Link href="/barbearia" className="menu-card">
          <div className="menu-card-icon">💈</div>
          <div className="menu-card-title">Barbearia</div>
          <div className="menu-card-sub">Agenda de clientes</div>
        </Link>

        <Link href="/iphones" className="menu-card">
          <div className="menu-card-icon">📱</div>
          <div className="menu-card-title">iPhones</div>
          <div className="menu-card-sub">Controle de vendas</div>
        </Link>
      </div>

      <p className="menu-footer">Criado por <strong>Adriel</strong></p>
    </main>
  );
}
