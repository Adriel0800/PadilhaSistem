import type { Metadata } from "next";
import "../styles/globals.css";

export const metadata: Metadata = {
  title: "Padilha Sistema",
  description: "Sistema de gestão — Barbearia & iPhones",
  icons: {
    icon: "/logoPadilha.ico",
    shortcut: "/logoPadilha.ico",
    apple: "/logoPadilha.png",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
