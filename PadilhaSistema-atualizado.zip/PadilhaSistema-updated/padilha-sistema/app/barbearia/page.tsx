"use client";

import { useEffect, useState } from "react";
import SemanaAgenda from "@/components/SemanaAgenda";
import Navbar from "@/components/Navbar";

const meses = [
  "Janeiro","Fevereiro","Março","Abril","Maio","Junho",
  "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"
];

function getSegundaAtual(): Date {
  const hoje = new Date();
  const dia = hoje.getDay();
  const diff = dia === 0 ? -6 : 1 - dia;
  const segunda = new Date(hoje);
  segunda.setDate(hoje.getDate() + diff);
  segunda.setHours(0, 0, 0, 0);
  return segunda;
}

function toISODate(d: Date): string {
  return d.toISOString().split("T")[0];
}

function getFimDaSemana(inicio: Date): Date {
  const fim = new Date(inicio);
  fim.setDate(inicio.getDate() + 6);
  return fim;
}

function getLabelSemana(inicio: Date): string {
  const fim = getFimDaSemana(inicio);
  const mesInicio = meses[inicio.getMonth()];
  const mesFim = meses[fim.getMonth()];
  const ano = fim.getFullYear();
  if (inicio.getMonth() === fim.getMonth()) {
    return `${inicio.getDate()} a ${fim.getDate()} de ${mesInicio} de ${ano}`;
  }
  return `${inicio.getDate()} de ${mesInicio} a ${fim.getDate()} de ${mesFim} de ${ano}`;
}

export default function Barbearia() {
  const [agendamentos, setAgendamentos] = useState([]);
  const [semanaInicio, setSemanaInicio] = useState(getSegundaAtual);

  const carregar = async (inicio: Date) => {
    const fim = getFimDaSemana(inicio);
    const res = await fetch(
      `/api/agendamentos?inicio=${toISODate(inicio)}&fim=${toISODate(fim)}`
    );
    const data = await res.json();
    setAgendamentos(Array.isArray(data) ? data : []);
  };

  useEffect(() => { carregar(semanaInicio); }, [semanaInicio]);

  const semanaAnterior = () => {
    const nova = new Date(semanaInicio);
    nova.setDate(semanaInicio.getDate() - 7);
    setSemanaInicio(nova);
  };

  const proximaSemana = () => {
    const nova = new Date(semanaInicio);
    nova.setDate(semanaInicio.getDate() + 7);
    setSemanaInicio(nova);
  };

  const voltarHoje = () => setSemanaInicio(getSegundaAtual());

  const salvar = async (dados: any) => {
    await fetch("/api/agendamentos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });
    carregar(semanaInicio);
  };

  const mover = async (dados: any) => {
    await fetch("/api/agendamentos", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });
    carregar(semanaInicio);
  };

  const deletar = async (id: string) => {
    await fetch("/api/agendamentos", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    carregar(semanaInicio);
  };

  const totalSemana = agendamentos.reduce((acc: number, a: any) => acc + (a.valor || 0), 0);
  const agendadosSemana = agendamentos.length;
  const isHoje = toISODate(semanaInicio) === toISODate(getSegundaAtual());

  return (
    <main className="page">
      <Navbar />

      <div className="page-header">
        <h1 className="display">Barbearia</h1>
        {agendadosSemana > 0 && (
          <span className="badge">
            {agendadosSemana} agendamento{agendadosSemana !== 1 ? "s" : ""} · R$ {totalSemana}
          </span>
        )}
      </div>

      {/* Navegação de semana */}
      <div className="nav-semana">
        <button className="nav-btn" onClick={semanaAnterior}>‹ Anterior</button>

        <div className="nav-label">
          <span className="label-semana">{getLabelSemana(semanaInicio)}</span>
          {!isHoje && (
            <button className="btn-hoje" onClick={voltarHoje}>Semana atual</button>
          )}
        </div>

        <button className="nav-btn" onClick={proximaSemana}>Próxima ›</button>
      </div>

      <SemanaAgenda
        agendamentos={agendamentos}
        semanaInicio={semanaInicio}
        onSave={salvar}
        onMove={mover}
        onDelete={deletar}
      />

      <div className="footer">
        Criado por <strong>Adriel</strong>
      </div>
    </main>
  );
}
