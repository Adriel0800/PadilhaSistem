import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";

// 🔍 LISTAR — filtra por intervalo de datas se fornecido
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const inicio = searchParams.get("inicio");
  const fim = searchParams.get("fim");

  let query = supabase.from("agendamentos").select("*");

  if (inicio && fim) {
    query = query.gte("data", inicio).lte("data", fim);
  }

  const { data, error } = await query;

  if (error) {
    console.error(error);
    return NextResponse.json({ error }, { status: 500 });
  }

  return NextResponse.json(data);
}

// ➕ CRIAR OU EDITAR
export async function POST(req: Request) {
  const body = await req.json();
  const { nome, valor, horario, data, id } = body;

  if (id) {
    const { error } = await supabase
      .from("agendamentos")
      .update({ nome, valor })
      .eq("id", id);

    if (error) return NextResponse.json({ error }, { status: 500 });
    return NextResponse.json({ ok: true });
  }

  // Verifica se já existe nesse horário/data
  const { data: existente } = await supabase
    .from("agendamentos")
    .select("*")
    .eq("data", data)
    .eq("horario", horario)
    .maybeSingle();

  if (existente) {
    const { error } = await supabase
      .from("agendamentos")
      .update({ nome, valor })
      .eq("id", existente.id);

    if (error) return NextResponse.json({ error }, { status: 500 });
    return NextResponse.json({ ok: true });
  }

  const { error } = await supabase
    .from("agendamentos")
    .insert([{ nome, valor, horario, data }]);

  if (error) return NextResponse.json({ error }, { status: 500 });
  return NextResponse.json({ ok: true });
}

// 🔀 MOVER (drag and drop)
export async function PUT(req: Request) {
  const body = await req.json();
  const { dataOrigem, horarioOrigem, dataDestino, horarioDestino } = body;

  const { data: agOrigem } = await supabase
    .from("agendamentos")
    .select("*")
    .eq("data", dataOrigem)
    .eq("horario", horarioOrigem)
    .maybeSingle();

  if (!agOrigem) return NextResponse.json({ error: "Não encontrado" }, { status: 404 });

  const { error } = await supabase
    .from("agendamentos")
    .update({ data: dataDestino, horario: horarioDestino })
    .eq("id", agOrigem.id);

  if (error) return NextResponse.json({ error }, { status: 500 });
  return NextResponse.json({ ok: true });
}

// ❌ DELETAR
export async function DELETE(req: Request) {
  const { id } = await req.json();

  const { error } = await supabase
    .from("agendamentos")
    .delete()
    .eq("id", id);

  if (error) return NextResponse.json({ error }, { status: 500 });
  return NextResponse.json({ ok: true });
}
