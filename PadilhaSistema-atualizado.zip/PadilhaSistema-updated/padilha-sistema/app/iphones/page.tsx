"use client";

import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";

export default function Iphones() {
  const [vendas, setVendas] = useState<any[]>([]);
  const [form, setForm] = useState({
    nome: "",
    produto: "",
    valor: "",
    custo: "",
    adiantamento: "",
    data: "",
    parcelas: "",
  });

  const carregar = async () => {
    const res = await fetch("/api/iphones");
    const data = await res.json();
    setVendas(Array.isArray(data) ? data : []);
  };

  useEffect(() => {
    carregar();
    setForm((f) => ({ ...f, data: new Date().toISOString().split("T")[0] }));
  }, []);

  const atualizar = (campo: string, val: string) =>
    setForm((f) => ({ ...f, [campo]: val }));

  const salvar = async () => {
    if (!form.nome || !form.produto || !form.valor) return;
    await fetch("/api/iphones", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome: form.nome,
        produto: form.produto,
        valor: Number(form.valor),
        custo: Number(form.custo),
        adiantamento: Number(form.adiantamento || 0),
        data: form.data,
        parcelas_total: Number(form.parcelas || 1),
      }),
    });
    setForm({ nome: "", produto: "", valor: "", custo: "", adiantamento: "", data: new Date().toISOString().split("T")[0], parcelas: "" });
    carregar();
  };

  const deletar = async (id: string) => {
    if (!confirm("Excluir esta venda?")) return;
    await fetch("/api/iphones", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    carregar();
  };

  const toggleParcela = async (id: string, index: number) => {
    await fetch("/api/iphones", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, index }),
    });
    carregar();
  };

  // Resumo
  const totalVendido = vendas.reduce((acc, v) => acc + v.valor, 0);
  const lucroTotal = vendas.reduce((acc, v) => acc + (v.valor - v.custo), 0);
  const totalReceber = vendas.reduce((acc, v) => {
    const restante = v.valor - (v.adiantamento || 0);
    const pagas = v.parcelas?.filter((p: boolean) => p).length || 0;
    const valorParcela = restante / (v.parcelas?.length || 1);
    return acc + (restante - pagas * valorParcela);
  }, 0);

  const fmt = (n: number) =>
    n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <main className="page">
      <Navbar />

      <div className="page-header">
        <h1 className="display">iPhones</h1>
        {vendas.length > 0 && (
          <span className="badge">{vendas.length} venda{vendas.length !== 1 ? "s" : ""}</span>
        )}
      </div>

      {/* Resumo */}
      <div className="resumo">
        <div className="resumo-card">
          <span className="resumo-label">Total vendido</span>
          <span className="resumo-valor">R$ {fmt(totalVendido)}</span>
        </div>
        <div className="resumo-card gold">
          <span className="resumo-label">Lucro total</span>
          <span className="resumo-valor">R$ {fmt(lucroTotal)}</span>
        </div>
        <div className="resumo-card">
          <span className="resumo-label">A receber</span>
          <span className="resumo-valor">R$ {fmt(totalReceber)}</span>
        </div>
      </div>

      {/* Formulário */}
      <div className="form-section">
        <div className="form-section-title">Registrar venda</div>
        <div className="form-grid">
          <div className="form-input-group span-2">
            <label>Cliente</label>
            <input placeholder="Nome do comprador" value={form.nome} onChange={(e) => atualizar("nome", e.target.value)} />
          </div>
          <div className="form-input-group span-2">
            <label>Produto</label>
            <input placeholder="Ex: iPhone 14 Pro 256GB" value={form.produto} onChange={(e) => atualizar("produto", e.target.value)} />
          </div>
          <div className="form-input-group">
            <label>Valor de venda (R$)</label>
            <input type="number" placeholder="0,00" value={form.valor} onChange={(e) => atualizar("valor", e.target.value)} />
          </div>
          <div className="form-input-group">
            <label>Custo (R$)</label>
            <input type="number" placeholder="0,00" value={form.custo} onChange={(e) => atualizar("custo", e.target.value)} />
          </div>
          <div className="form-input-group">
            <label>Entrada (R$)</label>
            <input type="number" placeholder="0,00" value={form.adiantamento} onChange={(e) => atualizar("adiantamento", e.target.value)} />
          </div>
          <div className="form-input-group">
            <label>Parcelas</label>
            <input type="number" placeholder="1" min="1" value={form.parcelas} onChange={(e) => atualizar("parcelas", e.target.value)} />
          </div>
          <div className="form-input-group">
            <label>Data</label>
            <input type="date" value={form.data} onChange={(e) => atualizar("data", e.target.value)} />
          </div>
        </div>
        <div className="form-actions">
          <button className="btn-registrar" onClick={salvar}>Registrar venda</button>
        </div>
      </div>

      {/* Lista de vendas */}
      {vendas.length === 0 ? (
        <div className="empty">Nenhuma venda registrada ainda.</div>
      ) : (
        <div className="lista">
          {vendas.map((v) => {
            const restante = v.valor - (v.adiantamento || 0);
            const totalParcelas = v.parcelas?.length || 1;
            const valorParcela = restante / totalParcelas;
            const lucro = v.valor - v.custo;
            const pagas = v.parcelas?.filter((p: boolean) => p).length || 0;

            return (
              <div key={v.id} className="card">
                <div className="card-head">
                  <div className="card-head-info">
                    <strong>{v.nome}</strong>
                    <span>{new Date(v.data + "T12:00:00").toLocaleDateString("pt-BR")}</span>
                  </div>
                  <div className="card-price">R$ {fmt(v.valor)}</div>
                </div>

                <div className="card-body">
                  <div className="card-produto">{v.produto}</div>
                  <div className="card-stats">
                    <div className="stat-item green">
                      <div className="stat-label">Lucro</div>
                      <div className="stat-val">R$ {fmt(lucro)}</div>
                    </div>
                    <div className="stat-item">
                      <div className="stat-label">Custo</div>
                      <div className="stat-val">R$ {fmt(v.custo)}</div>
                    </div>
                    <div className="stat-item">
                      <div className="stat-label">Entrada</div>
                      <div className="stat-val">R$ {fmt(v.adiantamento || 0)}</div>
                    </div>
                    <div className="stat-item">
                      <div className="stat-label">
                        {totalParcelas > 1
                          ? `${pagas}/${totalParcelas} parcelas`
                          : "Restante"}
                      </div>
                      <div className="stat-val">
                        {totalParcelas > 1
                          ? `R$ ${fmt(valorParcela)} /x`
                          : `R$ ${fmt(restante - pagas * valorParcela)}`}
                      </div>
                    </div>
                  </div>
                </div>

                {v.parcelas && v.parcelas.length > 1 && (
                  <div className="parcelas-section">
                    <div className="parcelas-label">
                      Parcelas — {pagas} de {totalParcelas} pagas
                    </div>
                    <div className="parcelas-grid">
                      {v.parcelas.map((p: boolean, i: number) => (
                        <div
                          key={i}
                          className={`box ${p ? "paga" : ""}`}
                          title={`Parcela ${i + 1}`}
                          onClick={() => toggleParcela(v.id, i)}
                        >
                          {i + 1}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="card-footer">
                  <button className="btn-delete" onClick={() => deletar(v.id)}>
                    Excluir venda
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="footer">Criado por <strong>Adriel</strong></div>
    </main>
  );
}
