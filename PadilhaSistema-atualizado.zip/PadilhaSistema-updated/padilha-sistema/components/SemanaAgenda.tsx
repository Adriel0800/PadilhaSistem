"use client";

import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

const diasNomes = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];

function getDatasDaSemana(semanaInicio: Date): Date[] {
  return diasNomes.map((_, i) => {
    const d = new Date(semanaInicio);
    d.setDate(semanaInicio.getDate() + i);
    return d;
  });
}

function toISODate(d: Date): string {
  return d.toISOString().split("T")[0];
}

function isHoje(d: Date): boolean {
  return toISODate(d) === toISODate(new Date());
}

function gerarHorarios(diaIndex: number): string[] {
  const horarios: string[] = [];
  const add = (inicio: string, fim: string) => {
    let [h, m] = inicio.split(":").map(Number);
    const [fh, fm] = fim.split(":").map(Number);
    while (h < fh || (h === fh && m <= fm)) {
      horarios.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
      m += 30;
      if (m >= 60) { m = 0; h++; }
    }
  };
  if (diaIndex === 6) return [];
  if (diaIndex === 5) { add("08:00", "12:00"); return horarios; }
  add("08:30", "11:30");
  add("13:30", "19:30");
  return horarios;
}

export default function SemanaAgenda({ agendamentos, semanaInicio, onSave, onMove, onDelete }: any) {
  const [popup, setPopup] = useState<any>(null);
  const [editando, setEditando] = useState<any>(null);
  const [nome, setNome] = useState("");
  const [valor, setValor] = useState("");

  const datas = getDatasDaSemana(semanaInicio);

  const buscar = (dataISO: string, horario: string) =>
    agendamentos.find((a: any) => a.data === dataISO && a.horario === horario);

  const salvar = () => {
    if (!nome || !valor) return;
    onSave({ id: editando?.id, nome, valor: Number(valor), horario: popup.horario, data: popup.dataISO });
    reset();
  };

  const excluir = () => { onDelete(editando.id); reset(); };

  const reset = () => { setPopup(null); setEditando(null); setNome(""); setValor(""); };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    const [dataOrigem, horarioOrigem] = result.source.droppableId.split("|");
    const [dataDestino, horarioDestino] = result.destination.droppableId.split("|");
    onMove({ dataOrigem, horarioOrigem, dataDestino, horarioDestino });
  };

  const formatarData = (iso: string) => iso?.split("-").reverse().join("/");

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="semana">
        {datas.map((data, index) => {
          const horarios = gerarHorarios(index);
          const dataISO = toISODate(data);
          const diaNum = data.getDate().toString().padStart(2, "0");
          const mesNum = (data.getMonth() + 1).toString().padStart(2, "0");
          const ehHoje = isHoje(data);

          return (
            <div key={dataISO} className="coluna">
              <h3 className={ehHoje ? "hoje-col" : ""}>
                {diasNomes[index]}
                <span className="data-dia">{diaNum}/{mesNum}</span>
              </h3>

              {horarios.length === 0 && <div className="fechado">Fechado</div>}

              {horarios.map((h) => {
                const ag = buscar(dataISO, h);
                return (
                  <Droppable key={`${dataISO}|${h}`} droppableId={`${dataISO}|${h}`}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`slot ${ag ? "ocupado" : "livre"}`}
                        onClick={() => {
                          if (ag) {
                            setEditando(ag);
                            setPopup({ dataISO, horario: h });
                            setNome(ag.nome);
                            setValor(ag.valor);
                          } else {
                            setPopup({ dataISO, horario: h });
                          }
                        }}
                      >
                        <span>{h}</span>
                        {ag && (
                          <Draggable draggableId={ag.id} index={0}>
                            {(provided) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                              >
                                <strong>{ag.nome}</strong>
                                <small>R$ {ag.valor}</small>
                              </div>
                            )}
                          </Draggable>
                        )}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                );
              })}
            </div>
          );
        })}
      </div>

      {popup && (
        <div className="overlay" onClick={(e) => e.target === e.currentTarget && reset()}>
          <div className="modal">
            <div className="modal-header">
              <h3>{editando ? editando.nome : "Novo agendamento"}</h3>
              <p>{formatarData(popup.dataISO)} às {popup.horario}</p>
            </div>

            <div className="modal-body">
              <div className="input-group">
                <label>Nome do cliente</label>
                <input
                  placeholder="Ex: João Silva"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  autoFocus
                />
              </div>
              <div className="input-group">
                <label>Valor (R$)</label>
                <input
                  placeholder="Ex: 35"
                  type="number"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                />
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={reset}>Cancelar</button>
              {editando && (
                <button className="btn btn-danger" onClick={excluir}>Excluir</button>
              )}
              <button className="btn btn-primary" onClick={salvar}>
                {editando ? "Salvar" : "Agendar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </DragDropContext>
  );
}
